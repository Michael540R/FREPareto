##### Results

# This file provides the code that was used to generate the results with genera-
# te.data() and strategy.eval() — which are included in GenerateData.R and 
# StrategyEvaluation.R. 


### Preliminaries

# mvtnorm package
library(mvtnorm)

# generate.data()
source("GenerateData.R")
# strategy.eval()
source("StrategyEvaluation.R")

# Vector of basis functions for y
phi <- Vectorize(function(u){
  c(1, 
    sapply(1:9, function(i){
      c(cos(i*(1.5*pi)*u), sin(i*(1.5*pi)*u))
    }),
    cos(10*(1.5*pi)*u))  
})

# Inner product matrix for phi
P.phi <- matrix(0, nrow = 20, ncol = 20)
for(i in 1:20){
  for(j in 1:20){
    P.phi[i,j] <- integrate(
      Vectorize(
        function(u) phi(u)[i]*phi(u)[j]
      ),
      lower = 0, upper = 1
    )$value
  }
}

# Inner product matrix for vec(t(phi)phi)

# The following code was used to produce this matrix. It can take a while to com-
# pute, therefore the file P.phiphi.RData has been provided if it is wished to
# to read the matrix immediately.

#P.phiphi <- matrix(0, nrow = 400, ncol = 400)
#phiphi.index <- as.matrix(expand.grid(1:20, 1:20))
#for(i in 1:400){
#  for(j in 1:400){
#    P.phiphi[i,j] <- integrate(
#      Vectorize(
#        function(u) phi(u)[phiphi.index[i,1]]*phi(u)[phiphi.index[i,2]]*
#          phi(u)[phiphi.index[j,1]]*phi(u)[phiphi.index[j,2]]
#      ),
#      lower = 0, upper = 1
#    )$value 
#    
#  }
#}

P.phiphi <- readRDS(file="P_phiphi.RData")


# Population

N <- 10000

# Model 1

# Vector of sample sizes
sample.sizes <- c(30, 50, 100, 250, 500, 1000, 2500, 3500)

# Vector of basis functions for x
phi.x <- phi

# Basis vector eta.star
phi.eta1 <- Vectorize(function(u){
  c(1, 
    sapply(1:3, function(i){
      c(cos(i*(1.5*pi)*u), sin(i*(1.5*pi)*u))
    }),
    cos(4*(1.5*pi)*u))  
})


# Inner product matrix x and eta.star
P.phi.x.eta1 <- matrix(0, nrow = 20, ncol = 8)
for(i in 1:20){
  for(j in 1:8){
    P.phi.x.eta1[i,j] <- integrate(
      Vectorize(
        function(u) phi.x(u)[i]*phi.eta1(u)[j]
      ),
      lower = 0, upper = 1
    )$value
  }
}

# Generate means
set.seed(1)
mu.x <- runif(N, min = 0, max = 1)

# Generate data (Model 1)
set.seed(1)
model1.data <- generate.data(
  N = N,
  points.x = seq(0,1, length = 20),
  l.x = 0.25,
  mu.x = mu.x,
  cv.x = 0.2,
  phi.x = phi.x,
  x_is_scalar = FALSE,
  l.beta = 0.15,
  kappa = 0.2, 
  delta = 1, 
  points.y = seq(0,1, length = 20), 
  l.y = 0.25, 
  phi = phi
)

# Evaluate strategies (Model 1)
set.seed(1)
model1.results <- strategy.eval(
  sample.sizes = sample.sizes, 
  draws = 10000,
  C = model1.data$C, 
  A = model1.data$A, 
  size.values = model1.data$size.values, 
  P.phi = P.phi, 
  P.phi.x.eta1 = P.phi.x.eta1, 
  P.phiphi = P.phiphi
)

saveRDS(model1.data, file="model1_data.RData")
saveRDS(model1.results, file="model1_results.RData")


# Generate data (Model 2)
set.seed(2)
model2.data <- generate.data(
  N = N,
  points.x = seq(0,1, length = 20),
  l.x = 0.25,
  mu.x = mu.x,
  cv.x = 0.2,
  phi.x = phi.x,
  x_is_scalar = FALSE,
  l.beta = 0.15,
  kappa = 0.1, 
  delta = 1, 
  points.y = seq(0,1, length = 20), 
  l.y = 0.25, 
  phi = phi
)
# Evaluate strategies (Model 2)
set.seed(2)
model2.results <- strategy.eval(
  sample.sizes = sample.sizes, 
  draws = 10000,
  C = model2.data$C, 
  A = model2.data$A, 
  size.values = model2.data$size.values, 
  P.phi = P.phi, 
  P.phi.x.eta1 = P.phi.x.eta1, 
  P.phiphi = P.phiphi
)

saveRDS(model2.data, file="model2_data.RData")
saveRDS(model2.results, file="model2_results.RData")


# Generate data (Model 3)
set.seed(3)
model3.data <- generate.data(
  N = N,
  points.x = seq(0,1, length = 20),
  l.x = 0.25,
  mu.x = mu.x,
  cv.x = 0.2,
  phi.x = phi.x,
  x_is_scalar = FALSE,
  l.beta = 0.15,
  kappa = 0.5, 
  delta = 1, 
  points.y = seq(0,1, length = 20), 
  l.y = 0.25, 
  phi = phi
)
# Evaluate strategies (Model 3)
set.seed(3)
model3.results <- strategy.eval(
  sample.sizes = sample.sizes, 
  draws = 10000,
  C = model3.data$C, 
  A = model3.data$A, 
  size.values = model3.data$size.values, 
  P.phi = P.phi, 
  P.phi.x.eta1 = P.phi.x.eta1, 
  P.phiphi = P.phiphi
)

saveRDS(model3.data, file="model3_data.RData")
saveRDS(model3.results, file="model3_results.RData")


# Generate data (Model 4)
set.seed(4)
model4.data <- generate.data(
  N = N,
  points.x = seq(0,1, length = 20),
  l.x = 0.25,
  mu.x = mu.x,
  cv.x = 0.2,
  phi.x = phi.x,
  x_is_scalar = FALSE,
  l.beta = 0.15,
  kappa = 0.2, 
  delta = 0.5, 
  points.y = seq(0,1, length = 20), 
  l.y = 0.25, 
  phi = phi
)
# Evaluate strategies (Model 4)
set.seed(4)
model4.results <- strategy.eval(
  sample.sizes = sample.sizes, 
  draws = 10000,
  C = model4.data$C, 
  A = model4.data$A, 
  size.values = model4.data$size.values, 
  P.phi = P.phi, 
  P.phi.x.eta1 = P.phi.x.eta1, 
  P.phiphi = P.phiphi
)

saveRDS(model4.data, file="model4_data.RData")
saveRDS(model4.results, file="model4_results.RData")

# Model 5

# Common mean
mu.x <- rep(0.5, times = N)


# Generate data (Model 5)
set.seed(5)
model5.data <- generate.data(
  N = N,
  points.x = seq(0,1, length = 20),
  l.x = 0.25,
  mu.x = mu.x,
  cv.x = 0.2,
  phi.x = phi.x,
  x_is_scalar = FALSE,
  l.beta = 0.15,
  kappa = 0.2, 
  delta = 1, 
  points.y = seq(0,1, length = 20), 
  l.y = 0.25, 
  phi = phi
)
# Evaluate strategies (Model 5)
set.seed(5)
model5.results <- strategy.eval(
  sample.sizes = sample.sizes, 
  draws = 10000,
  C = model5.data$C, 
  A = model5.data$A, 
  size.values = model5.data$size.values, 
  P.phi = P.phi, 
  P.phi.x.eta1 = P.phi.x.eta1, 
  P.phiphi = P.phiphi
)

saveRDS(model5.data, file="model5_data.RData")
saveRDS(model5.results, file="model5_results.RData")



# Model 6

# x is now a scalar
phi.x <- Vectorize(function(u){
1 
})

phi.eta1 <- phi.x

P.phi.x.eta1 <- matrix(1, nrow = 1, ncol = 1)

sample.sizes <- c(30, 50, 100, 250, 500, 1000, 2500)

set.seed(1)
mu.x <- runif(N, min = 0, max = 1)

# Generate data (Model 6)
set.seed(6)
model6.data <- generate.data(
  N = N,
  points.x = seq(0,1, length = 20),
  l.x = 0.25,
  mu.x = mu.x,
  cv.x = 0.2,
  phi.x = phi.x,
  x_is_scalar = TRUE,
  l.beta = 0.15,
  kappa = 0.2, 
  delta = 1, 
  points.y = seq(0,1, length = 20), 
  l.y = 0.25, 
  phi = phi
)
# Evaluate strategies (Model 6)
set.seed(6)
model6.results <- strategy.eval(
  sample.sizes = sample.sizes, 
  draws = 10000,
  C = model6.data$C, 
  A = model6.data$A, 
  size.values = model6.data$size.values, 
  P.phi = P.phi, 
  P.phi.x.eta1 = P.phi.x.eta1, 
  P.phiphi = P.phiphi
)

saveRDS(model6.data, file="model6_data.RData")
saveRDS(model6.results, file="model6_results.RData")

# Model 7

sample.sizes <- c(30, 50, 100, 250, 500, 1000, 2500, 3500)

phi.x <- phi

phi.eta1 <- Vectorize(function(u){
  c(1, 
    sapply(1:3, function(i){
      c(cos(i*(1.5*pi)*u), sin(i*(1.5*pi)*u))
    }),
    cos(4*(1.5*pi)*u))  
})

P.phi.x.eta1 <- matrix(0, nrow = 20, ncol = 8)
for(i in 1:20){
  for(j in 1:8){
    P.phi.x.eta1[i,j] <- integrate(
      Vectorize(
        function(u) phi.x(u)[i]*phi.eta1(u)[j]
      ),
      lower = 0, upper = 1
    )$value
  }
}

# Generate data (Model 7)
set.seed(7)
model7.data <- generate.data(
  N = N,
  points.x = seq(0,1, length = 20),
  l.x = 0.25,
  mu.x = mu.x,
  cv.x = 0.2,
  phi.x = phi.x,
  x_is_scalar = FALSE,
  l.beta = 0.15,
  kappa = 0.2, 
  delta = 1, 
  points.y = seq(0,1, length = 20), 
  l.y = 0.1, 
  phi = phi
)

# Evaluate strategies (Model 7)
set.seed(7)
model7.results <- strategy.eval(
  sample.sizes = sample.sizes, 
  draws = 10000,
  C = model7.data$C, 
  A = model7.data$A, 
  size.values = model7.data$size.values, 
  P.phi = P.phi, 
  P.phi.x.eta1 = P.phi.x.eta1, 
  P.phiphi = P.phiphi
)

saveRDS(model7.data, file="model7_data.RData")
saveRDS(model7.results, file="model7_results.RData")



# Generate data (Model 8)
set.seed(8)
model8.data <- generate.data(
  N = N,
  points.x = seq(0,1, length = 20),
  l.x = 0.25,
  mu.x = mu.x,
  cv.x = 0.2,
  phi.x = phi.x,
  x_is_scalar = FALSE,
  l.beta = 0.15,
  kappa = 0.2, 
  delta = 1, 
  points.y = seq(0,1, length = 20), 
  l.y = 0.5, 
  phi = phi
)

# Evaluate strategies (Model 8)
set.seed(8)
model8.results <- strategy.eval(
  sample.sizes = sample.sizes, 
  draws = 10000,
  C = model8.data$C, 
  A = model8.data$A, 
  size.values = model8.data$size.values, 
  P.phi = P.phi, 
  P.phi.x.eta1 = P.phi.x.eta1, 
  P.phiphi = P.phiphi
)

saveRDS(model8.data, file="model8_data.RData")
saveRDS(model8.results, file="model8_results.RData")





