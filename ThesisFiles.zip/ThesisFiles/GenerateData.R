##### Generate Data

# Provides the function generate.data() that generates coefficient matrices for
# y and x according to a specified superpopulation model.
# The mvtnorm package needs to be installed and loaded for the function to work.

#### generate.data()

generate.data <- function(
    N = 10000, # Size of population
    points.x, # Points where x should be evaluated
    l.x, # Parameter that controls correlation of x-values at adjacent points
    mu.x, # Means of x
    cv.x = 0.2, # Coefficient of variation for x
    phi.x, # Basis functions for x
    x_is_scalar = FALSE, # Is x a scalar?
    l.beta = 0.15, # Parameter that controls the degrees of smoothing for the
    # mean function of y
    kappa = 9, # Spread parameter for sigma.y
    delta = 2, # Shape parameter for sigma.y
    points.y, # Points where y should be evaluated
    l.y, # Parameter that controls correlation of y-values at adjacent points
    phi # Basis functions for y
){
  
  ### Population
  
  U <- 1:N
  
  ### Auxiliary functions
  
  n.points.x <- length(points.x) # Number of points where x is evaluated
  sigma.x <- cv.x*mu.x # Standard deviation for x

  if (x_is_scalar == FALSE){
  # Correlation function for x
  rho.x <- function(u1, u2){
    exp(-((u2-u1)^2)/(2*(l.x^2)))
  }
  # Matrix with correlation between x at different points
  rho.x.matrix <- matrix(
    apply(
      as.matrix(expand.grid(points.x, points.x)), MARGIN = 1, 
      FUN = function(u) rho.x(u[1], u[2])
    ),
    nrow = n.points.x, ncol = n.points.x
  ) 
  # Observed x-values
  x.obs <- sapply(U, function(k){
    rmvnorm(1, rep(mu.x[k], times = n.points.x), 
            sigma = (sigma.x[k]^2)*rho.x.matrix)
    
  }) 
  x.obs <- t(x.obs)
  try(if (any(x.obs < 0)) stop("Error: at least one x value is less than zero"))
  phi.x.obs <- t(sapply(points.x, phi.x)) # Observations on x basis
  A <- solve(t(phi.x.obs)%*%phi.x.obs)%*%t(phi.x.obs)%*%t(x.obs) # Matrix of co-
  # efficients for x basis
  A <- t(A)
  # Representation of x
  x <- sapply(U, function(k){
    Vectorize(function(u){
      A[k,]%*%phi.x(u)
    }
    )
  }) 
  }
  else {
    # If x is scalar
    A <- as.matrix(rnorm(N, mean = mu.x, sd = sigma.x), nrow = N, ncol = 1)
    try(if (any(A < 0)) stop("Error: at least one x value is less than zero"))
    x <- sapply(U, function(k){
      function(u) A[k,]
    })
  }
  
  ### Mu
  
  if(x_is_scalar == FALSE){
  
  # Functional Nadarya-Watson effect function
  beta <- function(u1, u2) dnorm(u2, mean = u1, sd = l.beta)/
    (pnorm(1, mean = u1, sd = l.beta)-pnorm(0, mean = u1, sd = l.beta))
  # Create mu
  mu <- sapply(
    U, function(k){
      Vectorize(
        function(u1){
          integrate(
            Vectorize(function(u2){
              x[[k]](u2)*beta(u1,u2)
            }), lower = 0, upper = 1
          )$value
        }
      )
    }
  )
  }
  else mu <- x # If x is scalar
  
  
  
  ### y
  
  # Standard deviation of y
  sigma.y <- sapply(U, function(k){
    Vectorize(function(u) kappa*(x[[k]](u)^delta))
  }) 
  # Correlation function of y
  rho.y <- function(u1, u2){
      exp(-((u2-u1)^2)/(2*(l.y^2)))
    }

  
  n.points.y <- length(points.y) 
  
  rho.matrix.y <- matrix(
      apply(
        as.matrix(expand.grid(points.y, points.y)), MARGIN = 1, 
        FUN = function(u) rho.y(u[1], u[2])
      ),
      nrow = n.points.y, ncol = n.points.y
    )
  
  
  # Generate observations on standardized errors
  error.standard.obs <- rmvnorm(N, sigma = rho.matrix.y)
  
  # Generate observations on y
  y.obs <- sapply(U, function(k){
    mu[[k]](points.y)+ sigma.y[[k]](points.y)*error.standard.obs[k,]
  })
  y.obs <- t(y.obs)
  
  
  # Interpolate/smooth to obtain representations of y
  phi.obs <- t(sapply(points.y, phi)) # Observations on basis functions
  C <- solve(t(phi.obs)%*%phi.obs)%*%t(phi.obs)%*%t(y.obs) # Matrix of constants
  C <- t(C)
  
  # Size values
  size.values <- sapply(U, function(k) integrate(Vectorize(
    function(u) sigma.y[[k]](u)^2), 
    lower = 0, upper = 1)$value)
  size.values <- sqrt(size.values)
  
  list("C" = C, "A" = A, "size.values" = size.values)
}
