##### Strategy Evaluation

# Provides the function strategy.eval() that gives evaluation metrics for the 4
# considered strategies. For each strategy the metrics considered are based on:
# MSE of tau.hat;
# Bias of tau.hat;
# MSE of gamma.hat, sigma2.hat, V.hat (L2 Variance estimate), and lambda.hat; 
# TMSE and WTMSE of psi.hat. 
# PRMSE is here the coefficient of variation (CV) and PBias is the percentage
# or relative bias.
# Metrics ending with .L or .U are lower and upper bounds for confidence 
# intervals
#
# The output of the functions is a list containing the norm of tau.y and an 
# array with metrics. The metrics are for the most part based on the Monte Carlo
# method. The mvtnorm package needs to be installed and loaded for the function 
# to work.


#### strategy.eval()

strategy.eval <- function(
    
  sample.sizes, # Vector of sample sizes for testing.
  draws = 10000, # Number of draws for the simulation are to be observed.
  C, # Matrix of constants for the observations on the study function y.
  A, # Matrix of constants for the observations on the auxiliary function x.
  size.values, # Size values that will be used to calculate target probabilitie-
  # s for the Pareto πps design.
  P.phi, # Inner product matrix for phi.
  P.phi.x.eta1, # Inner product matrix for the chosen basis for x and eta1
  P.phiphi # Inner product matrix for vec(t(phi)phi)..
  ){
  
  ### Population
  
  N <- nrow(C)
  U <- 1:N
  
  
  ### Total and Mean of y
  
  # Weights for total of y
  w <- colSums(C) # Weight vector for the total of y
  W <- t(sapply(1:draws, function(s) w)) # Matrix with weight vector of total o-
                                         # f y as rows 
  tau.norm <- sqrt(t(w)%*%P.phi%*%w) # Norm of total of y
  
  # Matrix with weight vector of mean of y as rows
  C.bar <- t(sapply(U, function(k) w/N))
  
  ### Obtain square root and inverse square root of P_phi
  
  # Square root of P_phi
  P.phi.root <- eigen(P.phi)$vectors%*%diag(sqrt(eigen(P.phi)$values))%*%
    t(eigen(P.phi)$vectors)
  # Square root of inverse of P_phi
  P.phi.root.inv <- solve(P.phi.root)
  
  ### Create trace function
  
  tr <- function(X) sum(diag(X))
  
  ### Simulation
  
  # Array with results of the simulation
  results <- array(0, 
                   dim = c(4,50, length(sample.sizes)),
                   dimnames = list(
                     "Strategy" = c("HT.SRS", 
                                    "FR.SRS", 
                                    "HT.Pareto", 
                                    "FR.Pareto"), 
                     "Measure" = c("RMSE.tau", 
                                   "RMSE.tau.L", 
                                   "RMSE.tau.U",
                                   "PRMSE.tau",
                                   "PRMSE.tau.L",
                                   "PRMSE.tau.U",
                                   "Bias",
                                   "PBias",
                                   "gamma.norm",
                                   "RMSE.gamma",
                                   "RMSE.gamma.L",
                                   "RMSE.gamma.U",
                                   "PRMSE.gamma",
                                   "PRMSE.gamma.L",
                                   "PRMSE.gamma.U",
                                   "sigma2.norm",
                                   "RMSE.sigma2",
                                   "RMSE.sigma2.L",
                                   "RMSE.sigma2.U",
                                   "PRMSE.sigma2",
                                   "PRMSE.sigma2.L",
                                   "PRMSE.sigma2.U",
                                   "lambda.norm",
                                   "RMSE.lambda",
                                   "RMSE.lambda.L",
                                   "RMSE.lambda.U",
                                   "PRMSE.lambda",
                                   "PRMSE.lambda.L",
                                   "PRMSE.lambda.U",
                                   "psi.norm",
                                   "RTMSE.psi",
                                   "RTMSE.psi.L",
                                   "RTMSE.psi.U",
                                   "PRTMSE.psi",
                                   "PRTMSE.psi.L",
                                   "PRTMSE.psi.U",
                                   "psi.weighted.norm",
                                   "RTWMSE.psi",
                                   "RTWMSE.psi.L",
                                   "RTWMSE.psi.U",
                                   "PRWTMSE.psi",
                                   "PRWTMSE.psi.L",
                                   "PRWTMSE.psi.U",
                                   "V.norm",
                                   "RMSE.V",
                                   "RMSE.V.L",
                                   "RMSE.V.U",
                                   "PRMSE.V",
                                   "PRMSE.V.L",
                                   "PRMSE.V.U"), 
                     "Sample_Size" = as.character(sample.sizes)))
  
  ### For loop over sample sizes
  
  for(i in 1:length(sample.sizes)){
    n <- sample.sizes[i]
    
    ### Simple Random Sample (SRS)
    
    ### Efficiency
    
    # Horvitz-Thompson
    
    f <- n/N
    #Covariance matrix of w_hat
    K.pi <- N*(1-f)/(f*(N-1))*
      t(C-C.bar)%*%(C-C.bar) 
    G.pi <- P.phi.root%*%K.pi%*%P.phi.root
    MSE.tau.pi <- tr(G.pi) # Mean square error of tau_hat
    
    
    results[1,1,i] <- sqrt(MSE.tau.pi) # RMSE.tau
    results[1,2,i] <- NA # RMSE.tau.L
    results[1,3,i] <- NA # RMSE.tau.U
    results[1,4,i] <- (sqrt(MSE.tau.pi)/tau.norm)*100 # PRMSE.tau 
    results[1,5,i] <- NA # PRMSE.tau.L
    results[1,6,i] <- NA # PRMSE.tau.U
    
  
    # Functional Regression
    
    # Generate draws of simple random samples without replacement
    samples.srs <- t(sapply(1:draws, function(k){
      sample(x = U, size = n)
    }))
    
    # Compute matrix with estimated weights for tau.y from each draw as rows
    W.hat.FR <- t(apply(samples.srs, MARGIN = 1,  function(s){
      AP <- A[s,, drop = FALSE]%*%P.phi.x.eta1
      PB.hat <- P.phi.x.eta1%*%
        solve(t(AP)%*%(AP))%*%t(AP)%*%C[s,, drop = FALSE]
      C.hat <- A%*%PB.hat # Matrix of constants for mu_hat
      E.s <- C[s,, drop = FALSE]-C.hat[s,, drop = FALSE] # Matrix of constants 
      # for residuals (sample)
      colSums(C.hat)+(N/n)*colSums(E.s)
    }))
    
    # Vector of Squared Errors
    squared.errors.FR <- diag((W.hat.FR-W)%*%P.phi%*%t(W.hat.FR-W))
    # MSE.tau (MC)
    MSE.tau.FR <- mean(squared.errors.FR)
    # Standard deviation for MSE.tau.FR
    MSE.tau.FR.sd <- sd(squared.errors.FR)/sqrt(draws)
    
    results[2,1,i] <- sqrt(MSE.tau.FR) # RMSE.tau (MC)
    results[2,2,i] <- sqrt(MSE.tau.FR-1.96*MSE.tau.FR.sd) # RMSE.tau.L (MC) 
    results[2,3,i] <- sqrt(MSE.tau.FR+1.96*MSE.tau.FR.sd) # RMSE.tau.U (MC) 
    results[2,4,i] <- 100*sqrt(MSE.tau.FR)/tau.norm # PRMSE.tau (MC)
    # PRMSE.tau.L (MC)
    results[2,5,i] <- 100*sqrt(MSE.tau.FR-1.96*MSE.tau.FR.sd)/tau.norm
    # PRMSE.tau.U (MC)
    results[2,6,i] <- 100*sqrt(MSE.tau.FR+1.96*MSE.tau.FR.sd)/tau.norm

    
    ### Bias
    
    # Horvitz-Thompson
    results[1,7,i] <- 0 # Bias
    results[1,8,i] <- 0 # Percentage bias
    
    # Functional Regression
    
    # Expected value of estimated weights (MC)
    w.FR.mean <- colMeans(W.hat.FR)
    # Bias (MC)
    results[2,7,i] <- sqrt(t(w.FR.mean-w)%*%P.phi%*%(w.FR.mean-w))
    # Percentage bias (MC)
    results[2,8,i] <- 100*sqrt(t(w.FR.mean-w)%*%P.phi%*%(w.FR.mean-w))/tau.norm
    
    ### Variance Assessment (gamma, sigma2, eigenvalues, eigenfunctions)
    
    # Horvitz Thompson 
  
    gamma.pi.norm <- sqrt(tr(G.pi%*%G.pi)) # Norm of covariance function
    sigma2.pi.norm <- sqrt(t(c(K.pi))%*%P.phiphi%*%c(K.pi)) # Norm of sigma2
    V.pi.norm <- sqrt(tr(G.pi)^2) # Norm of L2 Variance
    eigen.pi <- eigen(G.pi) 
    lambda.pi <- eigen.pi$values # Eigenvalues of Gamma
    # Length of vector of eigenvalues
    lambda.pi.norm <- sqrt(t(lambda.pi)%*%lambda.pi) 
    # Matrix of constants for eigenfunctions
    D.pi <- t(P.phi.root.inv%*%eigen.pi$vectors) 
    # Square root of sum of squared norms of eigenfunctions
    psi.pi.norm <- sqrt(tr(D.pi%*%P.phi%*%t(D.pi)))
    # Square root of sum of weighted squared norms of eigenfunctions
    psi.weights.pi <- lambda.pi/sum(lambda.pi)
    psi.pi.weighted.norm <- sqrt(sum(psi.weights.pi*
                                   diag(D.pi%*%P.phi%*%t(D.pi))))
    
    # Functional Regression
    
    # Matrix with w.FR.mean as rows
    W.FR.mean <- t(sapply(1:draws, function(s) w.FR.mean)) 
    # Covariance matrix for estimated weights (MC)
    K.FR.MC <- (1/(draws-1))*t(W.hat.FR-W.FR.mean)%*%(W.hat.FR-W.FR.mean)
    G.FR.MC <- P.phi.root%*%K.FR.MC%*%P.phi.root
    # Norm of gamma (MC)
    gamma.FR.norm <- sqrt(tr(G.FR.MC%*%G.FR.MC))
    # Norm of sigma2 (MC)
    sigma2.FR.norm  <- sqrt(t(c(K.FR.MC))%*%P.phiphi%*%c(K.FR.MC))
    # Norm of L2 Variance (MC)
    V.FR.norm <-sqrt(tr(G.FR.MC)^2)
    # Eigenvalues of Gamma (MC)
    eigen.FR <- eigen(G.FR.MC)
    lambda.FR <- eigen.FR$values
    # Length of vector of eigenvalues 
    lambda.FR.norm <- sqrt(t(lambda.FR)%*%lambda.FR)
    # Matrix of constants for eigenfunctions (MC)
    D.FR <- t(P.phi.root.inv%*%eigen.FR$vectors)
    # Square root of sum of squared norms of eigenfunctions 
    psi.FR.norm <- sqrt(tr(D.FR%*%P.phi%*%t(D.FR)))
    # Square root of sum of weighted squared norms of eigenfunctions
    psi.weights.FR <- lambda.FR/sum(lambda.FR)
    psi.FR.weighted.norm <- sqrt(sum(psi.weights.FR*diag(D.FR%*%P.phi%*%t(D.FR))))
    
    
    
    # Matrix with squared deviations for each draw as rows. These will be used
    # in order to calculate performance metrics for Gamma, sigma2, eigenvalues,
    # eigenfunctions 
    
    dev.srs <-  t(apply(samples.srs, MARGIN = 1,  function(s){
      
      # Horvitz-Thompson
    
      c.bar.s <- colMeans(C[s,]) # Sample mean
      # Matrix with the sample mean as rows
      C.bar.s <- rep(1, times = n)%*%t(c.bar.s) 
      # Estimate of K.pi
      K.pi.hat <- n*(1-f)/((f^2)*(n-1))*t(C[s,]-C.bar.s)%*%(C[s,]-C.bar.s)
      # Estimate of G.pi
      G.pi.hat <- P.phi.root%*%K.pi.hat%*%P.phi.root
      G.pi.dev <- G.pi.hat -G.pi
      # Estimate of eigenvalues of G.pi
      eigen.pi.hat <- eigen(G.pi.hat)
      lambda.pi.hat <- eigen.pi.hat$values
      # Estimate of D.pi
      D.pi.hat <- t(P.phi.root.inv%*%eigen.pi.hat$vectors)
     
      # Functional Regression
  
      AP <- A[s,, drop = FALSE]%*%P.phi.x.eta1
      PB.hat <- P.phi.x.eta1%*%solve(t(AP)%*%AP)%*%t(AP)%*%C[s,, drop = FALSE]
      C.hat.s <- A[s,]%*%PB.hat
      E.s <- C[s,, drop = FALSE]-C.hat.s
      # Matrix with sample mean of residuals as rows
      E.bar.s <- rep(1, times = n)%*%t(colMeans(E.s))
      # Estimate of K.FR
      K.FR.hat <- n*(1-f)/((f^2)*(n-1))*t(E.s-E.bar.s)%*%(E.s-E.bar.s)
      # Estimate of G.FR
      G.FR.hat <- P.phi.root%*%K.FR.hat%*%P.phi.root
      G.FR.dev <- G.FR.hat -G.FR.MC
      # # Estimate of eigenvalues of G.pi
      eigen.FR.hat <- eigen(G.FR.hat)
      lambda.FR.hat <- eigen.FR.hat$values
      # Estimate of D.FR
      D.FR.hat <- t(P.phi.root.inv%*%eigen.FR.hat$vectors)
      
      
      # Vector of squared deviations
      c(
        # Horvitz Thompson
        
        tr(G.pi.dev%*%G.pi.dev), # Dev for MSE.gamma
        t(c(K.pi.hat-K.pi))%*%P.phiphi%*%c(K.pi.hat-K.pi), # Dev for MSE.sigma2
        # Dev for MSE.lambda
         t(lambda.pi.hat-lambda.pi)%*%(lambda.pi.hat-lambda.pi), 
        # Dev for TMSE.psi
         sum(apply(
             cbind(diag((D.pi.hat-D.pi)%*%P.phi%*%t(D.pi.hat-D.pi)),
                   diag((-D.pi.hat-D.pi)%*%P.phi%*%t(-D.pi.hat-D.pi))
             ), 1, FUN = min)
         ),
        # Dev for TWMSE.psi
         sum(
           (lambda.pi/sum(lambda.pi))*apply(
             cbind(diag((D.pi.hat-D.pi)%*%P.phi%*%t(D.pi.hat-D.pi)),
                   diag((-D.pi.hat-D.pi)%*%P.phi%*%t(-D.pi.hat-D.pi))
             ), 1, FUN = min)
         ),
        # Dev for MSE.V
        tr(G.pi.dev)^2,
        
        # Functional Regression
        
        # Dev for MSE.gamma
        tr(G.FR.dev%*%G.FR.dev),
        # Dev for MSE.sigma2
         t(c(K.FR.hat-K.FR.MC))%*%P.phiphi%*%c(K.FR.hat-K.FR.MC),
        # Dev for MSE.lambda
         t(lambda.FR.hat-lambda.FR)%*%(lambda.FR.hat-lambda.FR),
        # Dev for TMSE.psi
         sum(
           apply(
             cbind(diag((D.FR.hat-D.FR)%*%P.phi%*%t(D.FR.hat-D.FR)),
                   diag((-D.FR.hat-D.FR)%*%P.phi%*%t(-D.FR.hat-D.FR))
             ), 1, FUN = min)
         ),
        # Dev for TWMSE.psi
         sum(
           (lambda.FR/sum(lambda.FR))*apply(
             cbind(diag((D.FR.hat-D.FR)%*%P.phi%*%t(D.FR.hat-D.FR)),
                   diag((-D.FR.hat-D.FR)%*%P.phi%*%t(-D.FR.hat-D.FR))
             ), 1, FUN = min)
         ),
        # Dev for MSE.V
        tr(G.FR.dev)^2
      )
    }))
   
    
    # Horvitz-Thompson
    
    # gamma
    
    # gamma.norm
    results[1, 9, i] <- gamma.pi.norm
    # RMSE.gamma (MC1)
    results[1, 10, i] <- sqrt(mean(dev.srs[,1]))
    # RMSE.gamma.L (MC1)
    results[1, 11, i] <- sqrt(mean(dev.srs[,1])-1.96*sd(dev.srs[,1])/
                                sqrt(draws))
    # RMSE.gamma.U (MC1)
    results[1, 12, i] <- sqrt(mean(dev.srs[,1])+1.96*sd(dev.srs[,1])/
                                sqrt(draws))
    # PRMSE.gamma (MC1)
    results[1, 13, i] <- 100*sqrt(mean(dev.srs[,1]))/gamma.pi.norm
    # PRMSE.gamma.L (MC1)
    results[1, 14, i] <- 100*sqrt(mean(dev.srs[,1])-1.96*sd(dev.srs[,1])/
                                    sqrt(draws))/gamma.pi.norm
    # PRMSE.gamma.U (MC1)
    results[1, 15, i] <- 100*sqrt(mean(dev.srs[,1])+1.96*sd(dev.srs[,1])/
                                    sqrt(draws))/gamma.pi.norm
    
    # sigma2
    
    # sigma2 norm
    results[1, 16, i] <- sigma2.pi.norm
    # RMSE.sigma2 (MC1)
    results[1, 17, i] <- sqrt(mean(dev.srs[,2]))
    # RMSE.sigma2.L (MC1)
    results[1, 18, i] <- sqrt(mean(dev.srs[,2])-1.96*sd(dev.srs[,2])/
                      sqrt(draws))
    # RMSE.sigma2.U (MC1)
    results[1, 19, i] <- sqrt(mean(dev.srs[,2])+1.96*sd(dev.srs[,2])/
                                sqrt(draws))
    # PRMSE.sigma2 (MC1)
    results[1, 20, i] <- 100*sqrt(mean(dev.srs[,2]))/sigma2.pi.norm
    # PRMSE.sigma2.L (MC1)
    results[1, 21, i] <- 100*sqrt(mean(dev.srs[,2])-1.96*sd(dev.srs[,2])/
                               sqrt(draws))/sigma2.pi.norm
    # PRMSE.sigma2.U (MC1)
    results[1, 22, i] <- 100*sqrt(mean(dev.srs[,2])+1.96*sd(dev.srs[,2])/
                                sqrt(draws))/sigma2.pi.norm
    
    # lambda
    
    # lambda.norm
    results[1, 23, i] <- lambda.pi.norm
    # RMSE.lambda (MC1)
    results[1, 24, i] <- sqrt(mean(dev.srs[,3]))
    # RMSE.lambda.L (MC1)
    results[1, 25, i] <- sqrt(mean(dev.srs[,3])-1.96*sd(dev.srs[,3])/
                                sqrt(draws))
    # RMSE.lambda.U (MC1)
    results[1, 26, i] <- sqrt(mean(dev.srs[,3])+1.96*sd(dev.srs[,3])/
                                sqrt(draws))
    # PRMSE.lambda (MC1)
    results[1, 27, i] <- 100*sqrt(mean(dev.srs[,3]))/lambda.pi.norm
    # PRMSE.lambda.L (MC1)
    results[1, 28, i] <- 100*sqrt(mean(dev.srs[,3])-1.96*sd(dev.srs[,3])/
                                    sqrt(draws))/lambda.pi.norm
    # PRMSE.lambda.U (MC1)
    results[1, 29, i] <- 100*sqrt(mean(dev.srs[,3])+1.96*sd(dev.srs[,3])/
                                    sqrt(draws))/lambda.pi.norm
    
    # psi
    
    # psi.norm
    results[1, 30, i] <- psi.pi.norm
    # RTMSE.psi (MC1)
    results[1, 31, i] <- sqrt(mean(dev.srs[,4]))
    # RTMSE.psi.L (MC1)
    results[1, 32, i] <- sqrt(mean(dev.srs[,4])-1.96*sd(dev.srs[,4])/
                                sqrt(draws))
    # RTMSE.psi.U (MC1)
    results[1, 33, i] <- sqrt(mean(dev.srs[,4])+1.96*sd(dev.srs[,4])/
                                sqrt(draws))
    # PRTMSE.psi (MC1)
    results[1, 34, i] <- 100*sqrt(mean(dev.srs[,4]))/psi.pi.norm
    # PRTMSE.psi.L (MC1)
    results[1, 35, i] <- 100*sqrt(mean(dev.srs[,4])-1.96*sd(dev.srs[,4])/
                                    sqrt(draws))/psi.pi.norm
    # PRTMSE.psi.U (MC1)
    results[1, 36, i] <- 100*sqrt(mean(dev.srs[,4])+1.96*sd(dev.srs[,4])/
                                    sqrt(draws))/psi.pi.norm
    
    # psi.weighted.norm
    results[1, 37, i] <- psi.pi.weighted.norm
    # RTWMSE (MC1)
    results[1, 38, i] <- sqrt(mean(dev.srs[,5]))
    # RTWMSE.L (MC1)
    results[1, 39, i] <- sqrt(mean(dev.srs[,5])-1.96*sd(dev.srs[,5])/
                                sqrt(draws))
    # RTWMSE.U (MC1)
    results[1, 40, i] <- sqrt(mean(dev.srs[,5])+1.96*sd(dev.srs[,5])/
                                sqrt(draws))
    # PRTWMSE (MC1)
    results[1, 41, i] <- 100*sqrt(mean(dev.srs[,5]))/psi.pi.weighted.norm
    # PRTWMSE.L (MC1)
    results[1, 42, i] <- 100*sqrt(mean(dev.srs[,5])-1.96*sd(dev.srs[,5])/
                                    sqrt(draws))/psi.pi.weighted.norm
    # PRTWMSE.U (MC1)
    results[1, 43, i] <- 100*sqrt(mean(dev.srs[,5])+1.96*sd(dev.srs[,5])/
                                    sqrt(draws))/psi.pi.weighted.norm
    
    # L2 Variance
    
    # V.norm
    results[1,44,i] <- V.pi.norm
    # RMSE.V (MC1)
    results[1,45,i] <- sqrt(mean(dev.srs[,6]))
    # RMSE.V.L (MC1)
    results[1,46,i] <- sqrt(mean(dev.srs[,6])-1.96*sd(dev.srs[,6])/
           sqrt(draws))
    # RMSE.V.U (MC1)
    results[1,47,i] <- sqrt(mean(dev.srs[,6])+1.96*sd(dev.srs[,6])/
                              sqrt(draws))
    # PRMSE.V (MC1)
    results[1,48,i] <- 100*sqrt(mean(dev.srs[,6]))/V.pi.norm
    # PRMSE.V.L (MC1)
    results[1,49,i] <- 100*sqrt(mean(dev.srs[,6])-1.96*sd(dev.srs[,6])/
           sqrt(draws))/V.pi.norm
    # PRMSE.V.U (MC1)
    results[1,50,i] <- 100*sqrt(mean(dev.srs[,6])+1.96*sd(dev.srs[,6])/
               sqrt(draws))/V.pi.norm
    
    # Functional Regression
    
    # gamma
    
    # gamma.norm (MC)
    results[2, 9, i] <- gamma.FR.norm
    # RMSE.gamma (MC2)
    results[2, 10, i] <- sqrt(mean(dev.srs[,7]))
    # RMSE.gamma.L (MC2)
    results[2, 11, i] <- sqrt(mean(dev.srs[,7])-1.96*sd(dev.srs[,7])/
                                sqrt(draws))
    # RMSE.gamma.U (MC2)
    results[2, 12, i] <- sqrt(mean(dev.srs[,7])+1.96*sd(dev.srs[,7])/
                                sqrt(draws))
    # PRMSE.gamma (MC2)
    results[2, 13, i] <- 100*sqrt(mean(dev.srs[,7]))/gamma.FR.norm
    # PRMSE.gamma.L (MC2)
    results[2, 14, i] <- 100*sqrt(mean(dev.srs[,7])-1.96*sd(dev.srs[,7])/
                                    sqrt(draws))/gamma.FR.norm
    # PRMSE.gamma.U (MC2)
    results[2, 15, i] <- 100*sqrt(mean(dev.srs[,7])+1.96*sd(dev.srs[,7])/
                                    sqrt(draws))/gamma.FR.norm
    
    # sigma2
    
    # sigma2.norm (MC2)
    results[2, 16, i] <- sigma2.FR.norm
    # RMSE.sigma2 (MC2)
    results[2, 17, i] <- sqrt(mean(dev.srs[,8]))
    # RMSE.sigma2.L (MC2)
    results[2, 18, i] <- sqrt(mean(dev.srs[,8])-1.96*sd(dev.srs[,8])/
                               sqrt(draws))
    # RMSE.sigma2.U (MC2)
    results[2, 19, i] <- sqrt(mean(dev.srs[,8])+1.96*sd(dev.srs[,8])/
                                sqrt(draws))
    # PRMSE.sigma2 (MC2)
    results[2, 20, i] <- 100*sqrt(mean(dev.srs[,8]))/sigma2.FR.norm
    # PRMSE.sigma2.L (MC2)
    results[2, 21, i] <- 100*sqrt(mean(dev.srs[,8])-1.96*sd(dev.srs[,8])/
                                    sqrt(draws))/sigma2.FR.norm
    # PRMSE.sigma2.U (MC2)
    results[2, 22, i] <- 100*sqrt(mean(dev.srs[,8])+1.96*sd(dev.srs[,8])/
                                    sqrt(draws))/sigma2.FR.norm
    
    # lambda
    
    # lambda.norm (MC)
    results[2, 23, i] <- lambda.FR.norm
    # RMSE.lambda (MC2)
    results[2, 24, i] <- sqrt(mean(dev.srs[,9]))
    # RMSE.lambda.L (MC2)
    results[2, 25, i] <- sqrt(mean(dev.srs[,9])-1.96*sd(dev.srs[,9])/
                                sqrt(draws))
    # RMSE.lambda.U (MC2)
    results[2, 26, i] <- sqrt(mean(dev.srs[,9])+1.96*sd(dev.srs[,9])/
                                sqrt(draws))
    # PRMSE.lambda (MC2)
    results[2, 27, i] <- 100*sqrt(mean(dev.srs[,9]))/lambda.FR.norm
    # PRMSE.lambda.L (MC2)
    results[2, 28, i] <- 100*sqrt(mean(dev.srs[,9])-1.96*sd(dev.srs[,9])/
                                    sqrt(draws))/lambda.FR.norm
    # PRMSE.lambda.U (MC2)
    results[2, 29, i] <- 100*sqrt(mean(dev.srs[,9])+1.96*sd(dev.srs[,9])/
                                    sqrt(draws))/lambda.FR.norm
    
    # psi
    
    # psi.norm (MC)
    results[2, 30, i] <- psi.FR.norm
    # RTMSE (MC2)
    results[2, 31, i] <- sqrt(mean(dev.srs[,10]))
    # RTMSE.L (MC2)
    results[2, 32, i] <- sqrt(mean(dev.srs[,10])-1.96*sd(dev.srs[,10])/
                                sqrt(draws))
    # RTMSE.U (MC2)
    results[2, 33, i] <- sqrt(mean(dev.srs[,10])+1.96*sd(dev.srs[,10])/
                                sqrt(draws))
    # PRTMSE (MC2)
    results[2, 34, i] <- 100*sqrt(mean(dev.srs[,10]))/psi.FR.norm
    # PRTMSE.L (MC2)
    results[2, 35, i] <- 100*sqrt(mean(dev.srs[,10])-1.96*sd(dev.srs[,10])/
                                    sqrt(draws))/psi.FR.norm
    # PRTMSE.U (MC2)
    results[2, 36, i] <- 100*sqrt(mean(dev.srs[,10])+1.96*sd(dev.srs[,10])/
                                    sqrt(draws))/psi.FR.norm
    
    # psi.weighted.norm (MC)
    results[2, 37, i] <- psi.FR.weighted.norm
    # RTWMSE (MC2)
    results[2, 38, i] <- sqrt(mean(dev.srs[,11]))
    # RTWMSE.L (MC2)
    results[2, 39, i] <- sqrt(mean(dev.srs[,11])-1.96*sd(dev.srs[,11])/
                                sqrt(draws))
    # RTWMSE.U (MC2)
    results[2, 40, i] <- sqrt(mean(dev.srs[,11])+1.96*sd(dev.srs[,11])/
                                sqrt(draws))
    # PRTWMSE (MC2)
    results[2, 41, i] <- 100*sqrt(mean(dev.srs[,11]))/psi.FR.weighted.norm
    # PRTWMSE.L (MC2)
    results[2, 42, i] <- 100*sqrt(mean(dev.srs[,11])-1.96*sd(dev.srs[,11])/
                                    sqrt(draws))/psi.FR.weighted.norm
    # PRTWMSE.U (MC2)
    results[2, 43, i] <- 100*sqrt(mean(dev.srs[,11])+1.96*sd(dev.srs[,11])/
                                    sqrt(draws))/psi.FR.weighted.norm
    # L2 Variance
    
    # V.norm
    results[2,44,i] <- V.FR.norm
    # RMSE.V (MC2)
    results[2,45,i] <- sqrt(mean(dev.srs[,12]))
    # RMSE.V.L (MC2)
    results[2,46,i] <- sqrt(mean(dev.srs[,12])-1.96*sd(dev.srs[,12])/
                              sqrt(draws))
    # RMSE.V.U (MC2)
    results[2,47,i] <- sqrt(mean(dev.srs[,12])+1.96*sd(dev.srs[,12])/
                              sqrt(draws))
    # PRMSE.V (MC2)
    results[2,48,i] <- 100*sqrt(mean(dev.srs[,12]))/V.FR.norm
    # PRMSE.V.L (MC2)
    results[2,49,i] <- 100*sqrt(mean(dev.srs[,12])-1.96*sd(dev.srs[,12])/
               sqrt(draws))/V.FR.norm
    # PRMSE.V.U (MC2)
    results[2,50,i] <- 100*sqrt(mean(dev.srs[,12])+1.96*sd(dev.srs[,12])/
               sqrt(draws))/V.FR.norm
    
    
    # Pareto πps 
    
    # Create target probabilities
    nu <- n*size.values/(sum(size.values))
    try(if(any(nu >= 1)) stop("Error: at least one target probability is equal 
                            to or greater than one"))
    
    # Obtain samples
    samples.pareto <- t(sapply(1:draws, function(k){
      R <- runif(N)
      H <- R*(1-nu)/(nu*(1-R))
      U[order(H)[1:n]]
    }))
    
    
    ### Efficiency
    
    # Quasi Horvitz-Thompson
    
    # Compute matrix with estimated weights of tau.y from each draw as rows
    W.hat.qpi <- t(apply(samples.pareto, MARGIN = 1, function(s){
      colSums(sweep(C[s,], 1,  1/nu[s], `*`))
    })
    )
    

    # Vector of squared errors
    squared.errors.qpi <- diag((W.hat.qpi-W)%*%P.phi%*%t(W.hat.qpi-W))
    # MSE of quasi Horvitz-Thompson estimator (MC)
    MSE.tau.qpi <- mean(squared.errors.qpi)
    # Standard deviation of MSE.qpi.MC1 
    MSE.tau.qpi.sd <- sd(squared.errors.qpi)/sqrt(draws)
    
  
    # RMSE.tau (MC)
    results[3,1,i] <- sqrt(MSE.tau.qpi)
    # RMSE.tau.L (MC)
    results[3,2,i] <- sqrt(MSE.tau.qpi-1.96*(MSE.tau.qpi.sd))
    # RMSE.tau.U (MC)
    results[3,3,i] <- sqrt(MSE.tau.qpi+1.96*(MSE.tau.qpi.sd))
    # PRMSE.tau (MC)
    results[3,4,i] <- 100*(sqrt(MSE.tau.qpi)/tau.norm)
    # PRMSE.tau.L (MC)
    results[3,5,i] <- 100*(sqrt(MSE.tau.qpi-1.96*(MSE.tau.qpi.sd))/tau.norm)
    # PRMSE.tau.U (MC)
    results[3,6,i] <- 100*(sqrt(MSE.tau.qpi+1.96*(MSE.tau.qpi.sd))/tau.norm)
    
    
    # Quasi Functional Regression
    
    # Compute matrix with estimated weights of tau.y from each draw as rows
    W.hat.qFR <- t(apply(samples.pareto, MARGIN = 1, function(s){
      # π expanded constants for y
      C.check <- sweep(C[s,, drop = FALSE], 1, 1/nu[s], `*`)
      AP <- A[s,, drop = FALSE]%*%P.phi.x.eta1
      PB.hat <- P.phi.x.eta1%*%
        solve(t(AP)%*%sweep(AP, 1, 1/nu[s], `*`))%*%t(AP)%*%C.check
      # Matrix of constants for mu.hat
      C.hat <- A%*%PB.hat 
      # Matrix of constants for residuals (sample)
      E.s <- C[s,, drop = FALSE]-C.hat[s,, drop = FALSE]
      colSums(C.hat)+colSums(sweep(E.s, 1, 1/nu[s], `*`))
    })
    )
    
    
    
    # Vector of squared errors
    squared.errors.qFR <- diag((W.hat.qFR-W)%*%P.phi%*%t(W.hat.qFR-W))
    # MSE of quasi functional regression estimator (MC)
    MSE.tau.qFR <- mean(squared.errors.qFR) 
    # Standard deviation of MSE.tau.qFR
    MSE.tau.qFR.sd <- sd(squared.errors.qFR)/sqrt(draws)
    
    # RMSE.tau (MC)
    results[4,1,i] <- sqrt(MSE.tau.qFR)
    # RMSE.tau.L (MC)
    results[4,2,i] <- sqrt(MSE.tau.qFR-1.96*(MSE.tau.qFR.sd))
    # RMSE.tau.U (MC)
    results[4,3,i] <- sqrt(MSE.tau.qFR+1.96*(MSE.tau.qFR.sd))
    # PRMSE.tau (MC)
    results[4,4,i] <- 100*(sqrt(MSE.tau.qFR)/tau.norm)
    # PRMSE.tau.L (MC)
    results[4,5,i] <- 100*(sqrt(MSE.tau.qFR-1.96*(MSE.tau.qFR.sd))/tau.norm)
    # PRMSE.tau.U (MC)
    results[4,6,i] <- 100*(sqrt(MSE.tau.qFR+1.96*(MSE.tau.qFR.sd))/tau.norm)
    
    
    ### Bias
    
    # Quasi Horvitz-Thompson
    
    # Expected value of estimated weights (MC)
    w.qpi.mean <- colMeans(W.hat.qpi)
    # Bias (MC) 
    results[3,7,i] <- sqrt(t(w.qpi.mean-w)%*%P.phi%*%(w.qpi.mean-w))
    # Percentage bias (MC) 
    results[3,8,i] <- 100*sqrt(t(w.qpi.mean-w)%*%P.phi%*%(w.qpi.mean-w))/tau.norm
    
    # Quasi Functional Regression
    
    # Expected value of estimated weights (MC)
    w.qFR.mean <- colMeans(W.hat.qFR)
    # Bias (MC) 
    results[4,7,i] <- sqrt(t(w.qFR.mean-w)%*%P.phi%*%(w.qFR.mean-w))
    # Percentage bias (MC) 
    results[4,8,i] <- 100*sqrt(t(w.qFR.mean-w)%*%P.phi%*%(w.qFR.mean-w))/tau.norm
    
    ### Variance Assessment (gamma, sigma2, eigenvalues, eigenfunctions)
    
    # Quasi Horvitz-Thompson 
    
    # Matrix with w.qpi.mean as rows
    W.qpi.mean <- t(sapply(1:draws, function(s) w.qpi.mean))
    # Covariance matrix of estimated weights (MC)
    K.qpi.MC<- (1/(draws-1))*t(W.hat.qpi-W.qpi.mean)%*%(W.hat.qpi-W.qpi.mean)
    G.qpi.MC <- P.phi.root%*%K.qpi.MC%*%P.phi.root
    
    # gamma norm (MC)
    gamma.qpi.norm <- sqrt(tr(G.qpi.MC%*%G.qpi.MC))
    # sigma2 norm (MC)
    sigma2.qpi.norm <- sqrt(t(c(K.qpi.MC))%*%P.phiphi%*%c(K.qpi.MC))
    # Norm of L2 Variance (MC)
    V.qpi.norm <-sqrt(tr(G.qpi.MC)^2)
    # Eigenvalues of G.qpi.MC
    eigen.qpi <- eigen(G.qpi.MC)
    lambda.qpi <- eigen.qpi$values
    # Length of vector of eigenvalues
    lambda.qpi.norm <- sqrt(t(lambda.qpi)%*%lambda.qpi)
    # Matrix of constants for eigenfunctions of Gamma (MC)
    D.qpi <- t(P.phi.root.inv%*%eigen.qpi$vectors)
    # Square root of sum of squared norms of eigenfunctions 
    psi.qpi.norm <- sqrt(tr(D.qpi%*%P.phi%*%t(D.qpi)))
    # Square root of sum of weighted squared norms of eigenfunctions
    psi.weights.qpi <- lambda.qpi/sum(lambda.qpi)
    psi.qpi.weighted.norm <- sqrt(sum(psi.weights.qpi*diag(D.qpi%*%P.phi%*%t(D.qpi))))
    
    
    # Functional Regression
    
    # Matrix with w.qFR.mean as rows
    W.qFR.mean <- t(sapply(1:draws, function(s) w.qFR.mean ))
    # Covariance matrix of estimated weights (MC)
    K.qFR.MC <- (1/(draws-1))*t(W.hat.qFR-W.qFR.mean)%*%(W.hat.qFR-W.qFR.mean)
    G.qFR.MC <- P.phi.root%*%K.qFR.MC%*%P.phi.root
    # gamma norm (MC)
    gamma.qFR.norm <- sqrt(tr(G.qFR.MC%*%G.qFR.MC))
    # sigma2 norm (MC)
    sigma2.qFR.norm <- sqrt(t(c(K.qFR.MC))%*%P.phiphi%*%c(K.qFR.MC))
    # Norm of L2 Variance (MC)
    V.qFR.norm <-sqrt(tr(G.qFR.MC)^2)
    # Eigenvalues of G.qFR.MC
    eigen.qFR <- eigen(G.qFR.MC)
    lambda.qFR <- eigen.qFR$values
    # Length of vector of eigenvalues
    lambda.qFR.norm <- sqrt(t(lambda.qFR)%*%lambda.qFR)
    # Matrix of constants for eigenfunctions of Gamma (MC)
    D.qFR <- t(P.phi.root.inv%*%eigen.qFR$vectors)
    # Square root of sum of squared norms of eigenfunctions 
    psi.qFR.norm <- sqrt(tr(D.qFR%*%P.phi%*%t(D.qFR)))
    # Square root of sum of weighted squared norms of eigenfunctions
    psi.weights.qFR <- lambda.qFR/sum(lambda.qFR)
    psi.qFR.weighted.norm <- sqrt(sum(psi.weights.qFR*diag(D.qFR%*%P.phi%*%t(D.qFR))))
    
    
    # Matrix with squared deviations for each draw as rows. These will be used
    # in order to calculate performance metrics for gamma, sigma2, eigenvalues,
    # eigenfunctions 
    
    dev.pareto<-  t(apply(samples.pareto, MARGIN = 1,  function(s){
      
      # Quasi Horvitz-Thompson
      
      # π expanded constants for y
      C.check <- sweep(C[s,, drop = FALSE], 1, 1/nu[s], `*`)
      c.prime <- as.vector(t((1-nu[s])/sum(1-nu[s]))%*%C.check)
      C.prime <- rep(1, times = n)%*%t(c.prime)
      C.dev <- sweep(C.check-C.prime, 1, sqrt(1-nu[s]), `*` )
      # Estimate of covariance matrix of estimated weights of tau.y
      K.qpi.hat <- (n/(n-1))*t(C.dev)%*%C.dev
      G.qpi.hat <- P.phi.root%*%K.qpi.hat%*%P.phi.root
      G.qpi.dev <- G.qpi.hat - G.qpi.MC
      # Estimate of eigenvalues of Gamma
      eigen.qpi.hat <- eigen(G.qpi.hat)
      lambda.qpi.hat <- eigen.qpi.hat$values
      # Matrix of estimated constants for eigenfunctions
      D.qpi.hat <- t(P.phi.root.inv%*%eigen.qpi.hat$vectors)
     
      
      # Quasi Functional Regression
      
      AP <- A[s,, drop = FALSE]%*%P.phi.x.eta1
      PB.hat <- P.phi.x.eta1%*%solve(t(AP)%*%sweep(AP, 1, 1/nu[s], `*`))%*%
        t(AP)%*%C.check
      # Matrix of constants for mu.hat (sample)
      C.hat.s <- A[s,]%*%PB.hat
      # Matrix of constants for residuals (sample)
      E.s <- C[s,, drop = FALSE]-C.hat.s
      E.check <- sweep(E.s, 1, 1/nu[s], `*`)
      e.prime <- as.vector(t((1-nu[s])/sum(1-nu[s]))%*%E.check)
      E.prime <- rep(1, times = n)%*%t(e.prime)
      E.dev <- sweep(E.check-E.prime, 1, sqrt(1-nu[s]), `*` )
      # Estimate of covariance matrix for estimated weights of tau.y
      K.qFR.hat <- (n/(n-1))*t(E.dev)%*%E.dev
      G.qFR.hat <- P.phi.root%*%K.qFR.hat%*%P.phi.root
      G.qFR.dev <- G.qFR.hat - G.qFR.MC
      # Estimate of eigenvalues of Gamma
      eigen.qFR.hat <- eigen(G.qFR.hat)
      lambda.qFR.hat <- eigen.qFR.hat$values
      # Matrix of estimated constants for eigenfunctions
      D.qFR.hat <- t(P.phi.root.inv%*%eigen.qFR.hat$vectors)
      
      # Vector of squared deviations
      c(
        # Quasi Horvitz-Thompson 
        
        # Dev for MSE.gamma
        tr(G.qpi.dev%*%G.qpi.dev),
        # Dev for MSE.sigma2
        t(c(K.qpi.hat-K.qpi.MC))%*%P.phiphi%*%c(K.qpi.hat-K.qpi.MC),
        # Dev for MSE.lambda
        t(lambda.qpi.hat-lambda.qpi)%*%(lambda.qpi.hat-lambda.qpi),
        # Dev for TMSE.psi
        sum(apply(
            cbind(diag((D.qpi.hat-D.qpi)%*%P.phi%*%t(D.qpi.hat-D.qpi)),
                  diag((-D.qpi.hat-D.qpi)%*%P.phi%*%t(-D.qpi.hat-D.qpi))
            ), 1, FUN = min)
        ),
        # Dev for TWMSE.psi
        sum(
          (lambda.qpi/sum(lambda.qpi))*apply(
            cbind(diag((D.qpi.hat-D.qpi)%*%P.phi%*%t(D.qpi.hat-D.qpi)),
                  diag((-D.qpi.hat-D.qpi)%*%P.phi%*%t(-D.qpi.hat-D.qpi))
            ), 1, FUN = min)
        ),
        # Dev for MSE.V
        tr(G.qpi.dev)^2,
        
        # Quasi Functional Regression
        
        # Dev for MSE.gamma
        tr(G.qFR.dev%*%G.qFR.dev),
        # Dev for MSE.sigma2
        t(c(K.qFR.hat-K.qFR.MC))%*%P.phiphi%*%c(K.qFR.hat-K.qFR.MC),
        # Dev for MSE.lambda
        t(lambda.qFR.hat-lambda.qFR)%*%(lambda.qFR.hat-lambda.qFR),
        # Dev for TMSE.psi
        sum(apply(
            cbind(diag((D.qFR.hat-D.qFR)%*%P.phi%*%t(D.qFR.hat-D.qFR)),
                  diag((-D.qFR.hat-D.qFR)%*%P.phi%*%t(-D.qFR.hat-D.qFR))
            ), 1, FUN = min)
        ),
        # Dev for TWMSE.psi
        sum(
          (lambda.qFR/sum(lambda.qFR))*apply(
            cbind(diag((D.qFR.hat-D.qFR)%*%P.phi%*%t(D.qFR.hat-D.qFR)),
                  diag((-D.qFR.hat-D.qFR)%*%P.phi%*%t(-D.qFR.hat-D.qFR))
            ), 1, FUN = min)
        ),
        # Dev for MSE.V
        tr(G.qFR.dev)^2
      )
      
    }))
    
    
    # Quasi Horvitz-Thompson
    
    # gamma
    
    # gamma.norm (MC)
    results[3, 9, i] <- gamma.qpi.norm
    # RMSE.gamma (MC1)
    results[3, 10, i] <- sqrt(mean(dev.pareto[,1]))
    # RMSE.gamma.L (MC2)
    results[3, 11, i] <- sqrt(mean(dev.pareto[,1])-1.96*sd(dev.pareto[,1])/
                                sqrt(draws))
    # RMSE.gamma.U (MC2)
    results[3, 12, i] <- sqrt(mean(dev.pareto[,1])+1.96*sd(dev.pareto[,1])/
                                sqrt(draws))
    # PRMSE.gamma (MC2)
    results[3, 13, i] <- 100*sqrt(mean(dev.pareto[,1]))/gamma.qpi.norm
    # PRMSE.gamma.L (MC2)
    results[3, 14, i] <- 100*sqrt(mean(dev.pareto[,1])-1.96*sd(dev.pareto[,1])/
                                    sqrt(draws))/gamma.qpi.norm
    # PRMSE.gamma.U (MC2)
    results[3, 15, i] <- 100*sqrt(mean(dev.pareto[,1])+1.96*sd(dev.pareto[,1])/
                                    sqrt(draws))/gamma.qpi.norm
    
    # sigma2
    
    # sigma2.norm (MC)
    results[3, 16, i] <- sigma2.qpi.norm
    # RMSE.sigma2 (MC2)
    results[3, 17, i] <- sqrt(mean(dev.pareto[,2]))
    # RMSE.sigma2.L (MC2)
    results[3, 18, i] <- sqrt(mean(dev.pareto[,2])-1.96*sd(dev.pareto[,2])/
                               sqrt(draws))
    # RMSE.sigma2.U (MC2)
    results[3, 19, i] <- sqrt(mean(dev.pareto[,2])+1.96*sd(dev.pareto[,2])/
                                sqrt(draws))
    # PRMSE.sigma2 (MC2)
    results[3, 20, i] <- 100*sqrt(mean(dev.pareto[,2]))/sigma2.qpi.norm
    # PRMSE.sigma2.L (MC2)
    results[3, 21, i] <- 100*sqrt(mean(dev.pareto[,2])-1.96*sd(dev.pareto[,2])/
                                    sqrt(draws))/sigma2.qpi.norm
    # PRMSE.sigma2.U (MC)
    results[3, 22, i] <- 100*sqrt(mean(dev.pareto[,2])+1.96*sd(dev.pareto[,2])/
                                    sqrt(draws))/sigma2.qpi.norm
    
    
    # lambda
    
    # lambda.norm (MC)
    results[3, 23, i] <- lambda.qpi.norm
    # RMSE.lambda (MC2)
    results[3, 24, i] <- sqrt(mean(dev.pareto[,3]))
    # RMSE.lambda.L (MC2)
    results[3, 25, i] <- sqrt(mean(dev.pareto[,3])-1.96*sd(dev.pareto[,3])/
                                sqrt(draws))
    # RMSE.lambda.U (MC2)
    results[3, 26, i] <- sqrt(mean(dev.pareto[,3])+1.96*sd(dev.pareto[,3])/
                                sqrt(draws))
    # PRMSE.lambda (MC2)
    results[3, 27, i] <- 100*sqrt(mean(dev.pareto[,3]))/lambda.qpi.norm
    # PRMSE.lambda.L (MC2)
    results[3, 28, i] <- 100*sqrt(mean(dev.pareto[,3])-1.96*sd(dev.pareto[,3])/
                                    sqrt(draws))/lambda.qpi.norm
    # PRMSE.lambda.U (MC2)
    results[3, 29, i] <- 100*sqrt(mean(dev.pareto[,3])+1.96*sd(dev.pareto[,3])/
                                    sqrt(draws))/lambda.qpi.norm
    
    # psi
    
    # psi.norm (MC)
    results[3, 30, i] <- psi.qpi.norm
    # RTMSE (MC2)
    results[3, 31, i] <- sqrt(mean(dev.pareto[,4]))
    # RTMSE.L (MC2)
    results[3, 32, i] <- sqrt(mean(dev.pareto[,4])-1.96*sd(dev.pareto[,4])/
                                sqrt(draws))
    # RTMSE.U (MC2)
    results[3, 33, i] <- sqrt(mean(dev.pareto[,4])+1.96*sd(dev.pareto[,4])/
                                sqrt(draws))
    # PRTMSE (MC2)
    results[3, 34, i] <- 100*sqrt(mean(dev.pareto[,4]))/psi.qpi.norm
    # PRTMSE.L (MC2)
    results[3, 35, i] <- 100*sqrt(mean(dev.pareto[,4])-1.96*sd(dev.pareto[,4])/
                                    sqrt(draws))/psi.qpi.norm
    # PRTMSE.U (MC2)
    results[3, 36, i] <- 100*sqrt(mean(dev.pareto[,4])+1.96*sd(dev.pareto[,4])/
                                    sqrt(draws))/psi.qpi.norm
    
    # psi.weighted.norm (MC)
    results[3, 37, i] <- psi.qpi.weighted.norm
    # RTWMSE (MC2)
    results[3, 38, i] <- sqrt(mean(dev.pareto[,5]))
    # RTWMSE.L (MC2)
    results[3, 39, i] <- sqrt(mean(dev.pareto[,5])-1.96*sd(dev.pareto[,5])/
                                sqrt(draws))
    # RTWMSE.U (MC2)
    results[3, 40, i] <- sqrt(mean(dev.pareto[,5])+1.96*sd(dev.pareto[,5])/
                                sqrt(draws))
    # PRTWMSE(MC2)
    results[3, 41, i] <- 100*sqrt(mean(dev.pareto[,5]))/psi.qpi.weighted.norm
    # PRTWMSE.L (MC2)
    results[3, 42, i] <- 100*sqrt(mean(dev.pareto[,5])-1.96*sd(dev.pareto[,5])/
                                    sqrt(draws))/psi.qpi.weighted.norm
    # PRTWMSE.U (MC2)
    results[3, 43, i] <- 100*sqrt(mean(dev.pareto[,5])+1.96*sd(dev.pareto[,5])/
                                    sqrt(draws))/psi.qpi.weighted.norm
    # L2 Variance
    
    # V.norm
    results[3,44,i] <- V.qpi.norm
    # RMSE.V (MC2)
    results[3,45,i] <- sqrt(mean(dev.pareto[,6]))
    # RMSE.V.L (MC2)
    results[3,46,i] <- sqrt(mean(dev.pareto[,6])-1.96*sd(dev.pareto[,6])/
                              sqrt(draws))
    # RMSE.V.U (MC2)
    results[3,47,i] <- sqrt(mean(dev.pareto[,6])+1.96*sd(dev.pareto[,6])/
                              sqrt(draws))
    # PRMSE.V (MC2)
    results[3,48,i] <- 100*sqrt(mean(dev.pareto[,6]))/V.qpi.norm
    # PRMSE.V.L (MC2)
    results[3,49,i] <- 100*sqrt(mean(dev.pareto[,6])-1.96*sd(dev.pareto[,6])/
                                  sqrt(draws))/V.qpi.norm
    # PRMSE.V.U (MC2)
    results[3,50,i] <- 100*sqrt(mean(dev.pareto[,6])+1.96*sd(dev.pareto[,6])/
                                  sqrt(draws))/V.qpi.norm
    
    # Quasi Functional Regression
    
    
    # gamma
    
    # gamma.norm (MC)
    results[4, 9, i] <- gamma.qFR.norm
    # RMSE.gamma (MC2)
    results[4, 10, i] <- sqrt(mean(dev.pareto[,7]))
    # RMSE.gamma.L (MC2)
    results[4, 11, i] <- sqrt(mean(dev.pareto[,7])-1.96*sd(dev.pareto[,7])/
                                sqrt(draws))
    # RMSE.gamma.U (MC2)
    results[4, 12, i] <- sqrt(mean(dev.pareto[,7])+1.96*sd(dev.pareto[,7])/
                                sqrt(draws))
    # PRMSE.gamma (MC2)
    results[4, 13, i] <- 100*sqrt(mean(dev.pareto[,7]))/gamma.qFR.norm
    # PRMSE.gamma.L (MC2)
    results[4, 14, i] <- 100*sqrt(mean(dev.pareto[,7])-1.96*sd(dev.pareto[,7])/
                                    sqrt(draws))/gamma.qFR.norm
    # PRMSE.gamma.U (MC2)
    results[4, 15, i] <- 100*sqrt(mean(dev.pareto[,7])+1.96*sd(dev.pareto[,7])/
                                    sqrt(draws))/gamma.qFR.norm
    
    
    # sigma2
    
    # sigma2.norm (MC)
    results[4, 16, i] <- sigma2.qFR.norm
    # RMSE.sigma2 (MC2)
    results[4, 17, i] <- sqrt(mean(dev.pareto[,8]))
    # RMSE.sigma2.L (MC2)
    results[4, 18, i] <- sqrt(mean(dev.pareto[,8])-1.96*sd(dev.pareto[,8])/
                               sqrt(draws))
    # RMSE.sigma2.U (MC2)
    results[4, 19, i] <- sqrt(mean(dev.pareto[,8])+1.96*sd(dev.pareto[,8])/
                                sqrt(draws))
    # PRMSE.sigma2 (MC2)
    results[4, 20, i] <- 100*sqrt(mean(dev.pareto[,8]))/sigma2.qFR.norm
    # PRMSE.sigma2.L (MC2)
    results[4, 21, i] <- 100*sqrt(mean(dev.pareto[,8])-1.96*sd(dev.pareto[,8])/
                                    sqrt(draws))/sigma2.qFR.norm
    # PRMSE.sigma2.U (MC2)
    results[4, 22, i] <- 100*sqrt(mean(dev.pareto[,8])+1.96*sd(dev.pareto[,8])/
                                    sqrt(draws))/sigma2.qFR.norm
    
    # lambda
    
    # lambda.norm (MC)
    results[4, 23, i] <- lambda.qFR.norm
    # RMSE.lambda (MC2)
    results[4, 24, i] <- sqrt(mean(dev.pareto[,9]))
    # RMSE.lambda.L (MC2)
    results[4, 25, i] <- sqrt(mean(dev.pareto[,9])-1.96*sd(dev.pareto[,9])/
                                sqrt(draws))
    # RMSE.lambda.U (MC2)
    results[4, 26, i] <- sqrt(mean(dev.pareto[,9])+1.96*sd(dev.pareto[,9])/
                                sqrt(draws))
    # PRMSE.lambda (MC2)
    results[4, 27, i] <- 100*sqrt(mean(dev.pareto[,9]))/lambda.qFR.norm
    # PRMSE.lambda.L (MC2)
    results[4, 28, i] <- 100*sqrt(mean(dev.pareto[,9])-1.96*sd(dev.pareto[,9])/
                                    sqrt(draws))/lambda.qFR.norm
    # PRMSE.lambda.U (MC2)
    results[4, 29, i] <- 100*sqrt(mean(dev.pareto[,9])+1.96*sd(dev.pareto[,9])/
                                    sqrt(draws))/lambda.qFR.norm
    
    # psi
    
    # psi.norm (MC)
    results[4, 30, i] <- psi.qFR.norm
    # RTMSE (MC2)
    results[4, 31, i] <- sqrt(mean(dev.pareto[,10]))
    # RTMSE.L (MC2)
    results[4, 32, i] <- sqrt(mean(dev.pareto[,10])-1.96*sd(dev.pareto[,10])/
                                sqrt(draws))
    # RTMSE.U (MC2)
    results[4, 33, i] <- sqrt(mean(dev.pareto[,10])+1.96*sd(dev.pareto[,10])/
                                sqrt(draws))
    # PRTMSE (MC2)
    results[4, 34, i] <- 100*sqrt(mean(dev.pareto[,10]))/psi.qFR.norm
    # PRTMSE.L (MC2)
    results[4, 35, i] <- 100*sqrt(mean(dev.pareto[,10])-1.96*sd(dev.pareto[,10])/
                                    sqrt(draws))/psi.qFR.norm
    # PRTMSE.U (MC2)
    results[4, 36, i] <- 100*sqrt(mean(dev.pareto[,10])+1.96*sd(dev.pareto[,10])/
                                    sqrt(draws))/psi.qFR.norm
    
    # psi.weighted.norm (MC)
    results[4, 37, i] <- psi.qFR.weighted.norm
    # RTWMSE (MC2)
    results[4, 38, i] <- sqrt(mean(dev.pareto[,11]))
    # RTWMSE.L (MC2)
    results[4, 39, i] <- sqrt(mean(dev.pareto[,11])-1.96*sd(dev.pareto[,11])/
                                sqrt(draws))
    # RTWMSE.U (MC2)
    results[4, 40, i] <- sqrt(mean(dev.pareto[,11])+1.96*sd(dev.pareto[,11])/
                                sqrt(draws))
    # PRTWMSE (MC2)
    results[4, 41, i] <- 100*sqrt(mean(dev.pareto[,11]))/psi.qFR.weighted.norm
    # PRTWMSE.L (MC2)
    results[4, 42, i] <- 100*sqrt(mean(dev.pareto[,11])-1.96*sd(dev.pareto[,11])/
                                    sqrt(draws))/psi.qFR.weighted.norm
    # PRTWMSE.U (MC2)
    results[4, 43, i] <- 100*sqrt(mean(dev.pareto[,11])+1.96*sd(dev.pareto[,11])/
                                    sqrt(draws))/psi.qFR.weighted.norm
    
    # L2 Variance
    
    # V.norm
    results[4,44,i] <- V.qFR.norm
    # RMSE.V (MC2)
    results[4,45,i] <- sqrt(mean(dev.pareto[,12]))
    # RMSE.V.L (MC2)
    results[4,46,i] <- sqrt(mean(dev.pareto[,12])-1.96*sd(dev.pareto[,12])/
                              sqrt(draws))
    # RMSE.V.U (MC2)
    results[4,47,i] <- sqrt(mean(dev.pareto[,12])+1.96*sd(dev.pareto[,12])/
                              sqrt(draws))
    # PRMSE.V (MC2)
    results[4,48,i] <- 100*sqrt(mean(dev.pareto[,12]))/V.qFR.norm
    # PRMSE.V.L (MC2)
    results[4,49,i] <- 100*sqrt(mean(dev.pareto[,12])-1.96*sd(dev.pareto[,12])/
                                  sqrt(draws))/V.qFR.norm
    # PRMSE.V.U (MC2)
    results[4,50,i] <- 100*sqrt(mean(dev.pareto[,12])+1.96*sd(dev.pareto[,12])/
                                  sqrt(draws))/V.qFR.norm
    
 
    }
  list(tau.norm, Re(results))
  
}
